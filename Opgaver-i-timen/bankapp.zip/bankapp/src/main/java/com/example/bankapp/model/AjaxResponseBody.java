package com.example.bankapp.model;

public class AjaxResponseBody {

    private String msg;
    private GoldenCow cow;

    public AjaxResponseBody() {
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public GoldenCow getCow() {
        return cow;
    }

    public void setCow(GoldenCow cow) {
        this.cow = cow;
    }
}
