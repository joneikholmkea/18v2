package dat16c.example.demo;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpSession;
import java.util.*;

@Controller
public class IndexController {

    private List<User> users = new ArrayList<>();

    public IndexController(){

        Map<Integer,Account> accounts = new HashMap<>();
        User user = new User("Knock", "123456", accounts);
        accounts.put(1,new Account(1000, 1));
        accounts.put(2,new Account(500, 2));
        accounts.put(3,new Account(1500, 3));
        users.add(user);
    }

    @RequestMapping(value = {"/ajax2.html"}, method = RequestMethod.GET)
    public String getAjaxPage(){
        return "ajax2";
    }

    @RequestMapping(value = {"/", "/index.html"}, method = RequestMethod.GET)
    public String getIndexPage(){
        return "index";
    }

    @RequestMapping(value = {"/bank.html"}, method = RequestMethod.GET)
    public String getBankPage(HttpSession httpSession){
        if(httpSession.getAttribute("isLoggedIn").equals("yes")){
            return "bank";
        }else {
            return "redirect:/index.html";
        }
    }

   // @RequestMapping(value = {"/bank.html"}, method = RequestMethod.GET , params = "logoutbutton")
    @GetMapping(value = "/bank.html", params = "logoutbutton")
    public String logoutPressed(HttpSession httpSession){
        httpSession.setAttribute("isLoggedIn", "no");
        System.out.println("sending user to index page after logout");
        return "redirect:/";
    }

    //@RequestMapping(value = {"/bank.html"}, method = RequestMethod.POST)
    @PostMapping(value = {"/bank.html"})
    public String transferPressed(Transfer transfer, HttpSession httpSession, Model model){
        if(httpSession.getAttribute("isLoggedIn").equals("yes")) {
            System.out.println("processing transfer...");
            double f = users.get(0).getAccounts().get(transfer.getFromAccountNumber()).getAmount();
            users.get(0).getAccounts().get(transfer.getFromAccountNumber()).setAmount(f - transfer.getAmount());

            double t = users.get(0).getAccounts().get(transfer.getToAccountNumber()).getAmount();
            users.get(0).getAccounts().get(transfer.getToAccountNumber()).setAmount(t + transfer.getAmount());
            // make list from map
            List<Account> list = convertToList(users.get(0).getAccounts());
            model.addAttribute("accounts", list);
            return "bank";
        }else {
            return "redirect:/index.html";
        }
    }

    private List<Account> convertToList(Map<Integer,Account> map){
        return new ArrayList<>(map.values());
    }

    @RequestMapping(value = "/index.html", method = RequestMethod.POST)
    public String loginPressed(@ModelAttribute LoginAttempt login, Model model, HttpSession session){  // @ModelAttribute  is not necessary...
        System.out.println("getIndexPage called with " + login.getUsername());
        if(checkUser(login)){
            session.setAttribute("isLoggedIn", "yes");

            model.addAttribute("accounts", convertToList(users.get(0).getAccounts())); // just show user 0's accounts
            return "bank";
        }else {
            session.setAttribute("isLoggedIn", "no");
            System.out.println("Failed login attempt");
        }

        return "index";
    }

    private boolean checkUser(LoginAttempt login){
        return login.getUsername().equals("Knock") && login.getPassword().equals("123456");

    }

}
