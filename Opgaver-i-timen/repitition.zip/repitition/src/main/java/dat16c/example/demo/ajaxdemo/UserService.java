package dat16c.example.demo.ajaxdemo;

import dat16c.example.demo.ajaxdemo.User2;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service // tells Spring, that this class belongs to the service layer
public class UserService {

    private List<User2> users;

    // Love Java 8
    public List<User2> findByUserNameOrEmail(String username) {

        List<User2> result = users.stream()
                .filter(x -> x.getUsername().equalsIgnoreCase(username))
                .collect(Collectors.toList());

        return result;

    }

    // Init some users for testing, instead of calling this method from constructor
    @PostConstruct
    private void iniDataForTesting() {

        users = new ArrayList<>();

        User2 user1 = new User2("mkyong", "password111", "mkyong@yahoo.com");
        User2 user2 = new User2("yflow", "password222", "yflow@yahoo.com");
        User2 user3 = new User2("laplap", "password333", "mkyong@yahoo.com");
        User2 user4 = new User2("mkyong", "ramboneverforgets", "rambo@yahoo.com");

        users.add(user1);
        users.add(user2);
        users.add(user3);
        users.add(user4);

    }

}
