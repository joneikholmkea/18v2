package dat16c.example.demo.ajaxdemo;

import java.util.List;

public class AjaxResponseBody {
// This class has no annotations. But since it's fields are String based, they can be
    // accessed on the client side, using javascript object notation (JSON)
    private String msg;
    private List<User2> result;

    public String getMsg() { // this will respond to a Object.msg call on the client-side.
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public List<User2> getResult() {
        return result;
    }

    public void setResult(List<User2> result) {
        this.result = result;
    }
//getters and setters

}
