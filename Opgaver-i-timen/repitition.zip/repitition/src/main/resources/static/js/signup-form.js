// https://jqueryvalidation.org/files/demo/index.html
$().ready(function () { // using jQuery to select element

   $("#form1").validate({ //will check on each key-up event
       rules:{
           username: {
               required : true,
               minlength: 2
           }
       },
       messages: {
           username: "Venligst indtast brugernavn"
       }
   });
});
